

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h1 class="text-center mb-4">Select a Quiz</h1>
        <div class="card shadow-lg p-4" style="border-radius: 15px; background-color: #F0F4F7;">
            <div class="card-body">
                <div class="row justify-content-center">
                    <?php $__currentLoopData = $quizzes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 mb-4">
                            <div class="result-section p-4 mx-auto" style="background-color: #ffffff; border-radius: 10px; max-width: 400px; box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);">
                                <h5 class="card-title font-weight-bold text-center"><?php echo e($quiz->title); ?></h5>
                                <p class="card-text text-muted text-center">
                                    <?php if($quiz->id == 1): ?>
                                        Before you hop around and see what's going on in Mental Health Week, please take your time to finish this quiz first.
                                    <?php else: ?>
                                        Now that you've gone around the booths in Mental Health Week, please take your time to fill out this quiz.
                                    <?php endif; ?>
                                </p>

                                <?php if($quiz->id == 1 || ($quiz->id == 2 && $quiz1Result)): ?>
                                    <!-- Enable Quiz 1 or Quiz 2 if Quiz 1 is completed -->
                                    <a href="<?php echo e(route('quizzes.showQuestions', $quiz->id)); ?>" class="btn btn-primary btn-lg w-100">
                                        Start <?php echo e($quiz->title); ?>

                                    </a>
                                <?php elseif($quiz->id == 2 && !$quiz1Result): ?>
                                    <!-- Disable Quiz 2 if Quiz 1 is not completed -->
                                    <button class="btn btn-secondary btn-lg w-100" disabled>
                                        Complete Quiz 1 to Unlock This Quiz
                                    </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hansj\OneDrive\Documents\Student Affairs\Projects\Website Psychometric\psychology-web\resources\views/quizzes.blade.php ENDPATH**/ ?>