

<?php $__env->startSection('title', 'Your Results'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <div class="card shadow-lg p-4" style="border-radius: 15px; background-color: #F0F4F7;">
            <div class="card-body text-center">
                <?php if(session('logged_in')): ?>
                    <h1 class="display-4 mb-4">Your Results</h1>
                    <p class="lead">Thank you for completing the surveys! Below are your results:</p>

                    <?php if($quiz1): ?>
                        <div class="result-section mt-5 p-4 mx-auto" style="background-color: #ffffff; border-radius: 10px; max-width: 400px; box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);">
                            <h3 class="text-info">Quiz 1 Result</h3>
                            <p class="mt-3"><strong>Analysis:</strong> <?php echo e($quiz1->analysis); ?></p>
                        </div>
                    <?php else: ?>
                        <p class="text-warning mt-4">Please finish Quiz 1 to see your result.</p>
                    <?php endif; ?>

                    <?php if($quiz2): ?>
                        <div class="result-section mt-5 p-4 mx-auto" style="background-color: #ffffff; border-radius: 10px; max-width: 400px; box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);">
                            <h3 class="text-info">Quiz 2 Result</h3>
                            <p class="mt-3"><strong>Analysis: </strong> <?php echo e($quiz2->analysis); ?></p>
                        </div>
                    <?php else: ?>
                        <p class="text-warning mt-4">Please finish Quiz 2 to see your result.</p>
                    <?php endif; ?>

                    <a href="<?php echo e(url('/')); ?>" class="btn btn-success btn-lg mt-5" style="border-radius: 25px;">Go Back to Home</a>
                <?php else: ?>
                    <h1 class="display-5 text-danger"><?php echo e(session('error')); ?></h1>
                    <p class="lead">You need to be logged in to see your results.</p>
                    <a href="<?php echo e(url('/login')); ?>" class="btn btn-primary btn-lg mt-4">Login</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hansj\OneDrive\Documents\Student Affairs\Projects\Website Psychometric\psychology-web\resources\views/result.blade.php ENDPATH**/ ?>