<?php $__env->startSection('title', 'Welcome to the Quiz'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-lg-6">
            <div class="card shadow-sm">
                <div class="card-body text-center">
                    <h1 class="card-title">Well Being Survey</h1>
                    <p class="card-text">Before you explore our booths in the event, please take your time to fill out our well being survey.</p>
                    <p class="card-text">Please enjoy the event!!</p>
                    <!-- Update the route to correctly direct to the quiz questions -->
                    <a href="<?php echo e(route('quizzes.index')); ?>" class="btn btn-primary btn-lg">Start Quiz</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hansj\OneDrive\Documents\Student Affairs\Projects\Website Psychometric\psychology-web\resources\views/index.blade.php ENDPATH**/ ?>